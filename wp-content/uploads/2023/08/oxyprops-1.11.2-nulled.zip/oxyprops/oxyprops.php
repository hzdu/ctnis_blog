<?php
/**
 * OxyProps WordPress Plugin
 * A modern CSS Framework and Productivity Tools for building your WordPress Site with your favorite page buidler
 *
 * @package     OxyProps
 * @author      Cédric Bontems <dev@oxyprops.com>
 * @copyright   2022-2023 Cédric Bontems - The Web Forge
 * @license     https://www.gnu.org/licenses/gpl-2.0.html  GPL v2 or later
 * @link        https://oxyprops.com                       OxyProps Website
 * @since       0.1.0
 *
 * @wordpress-plugin
 * Plugin Name:       OxyProps
 * Plugin URI:        https://oxyprops.com
 * Description:       A modern CSS Framework and Productivity Tools for building your WordPress Site.
 * Version:           1.11.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Cédric Bontems - The Web Forge
 * Author URI:        https://thewebforge.dev
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       oxyprops
 * Domain Path:       /languages
 *
 * Copyright (c) 2022 Cédric Bontems - The Web Forge
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * This program incorporates work covered by the following copyright and
 * permission notices:
 *
 *   Open Props is Copyright (c) 2021 Adam Argyle - https://open-props.style
 *   Open Props is released under the MIT license
 */

use OxyProps\Inc\Init;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Require once our Autoload.
if ( ! defined( 'OXYPROPS_AUTOLOAD_VERSION' ) ) {
	require_once dirname( __FILE__ ) . '/includes/autoload.php';
}

// Initialize all the core classes of the plugin.

Init::register_services();
