<?php
/**
 * Trigger this file on uninstall
 * @package OxyProps
 * @since 0.2.0
 * @author Cédric Bontems <contact@oxyprops.com>
 */

use OxyProps\Inc\Helpers;

if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

// Clear DB stored data

global $wpdb;
$wpdb->query("DELETE FROM wp_options WHERE option_name LIKE 'oxyprops%'");