## v1.11.1 (2023-07-30)

### Fix

- compatibility with BricksForge

## v1.11.0 (2023-07-13)

## v1.10.2-dev2 (2023-07-13)

### Feat

- **all**: normalize assigns the new text-wrap balance to headings and text-wrap pretty to paragraphs
- **all**: new classes for the newly supported text-wrap property
- **all**: create new container fuid font sizes and make them available in fontsize context menus
- **all**: add new props for container based fluid typography
- **all**: add new container queries classes

## v1.10.2-dev1 (2023-07-11)

### Fix

- **oxy**: fixed context menus in Oxygen triggering errors
- **all**: restored submenu items in dashboard

## v1.10.1 (2023-07-09)

### Fix

- **brx**: unlimited icon element now renders properly from dynamic data

## v1.10.0 (2023-07-07)

### Feat

- **all**: add settings to give users full control over theme-color meta

### Fix

- **all**: code cleanup and minimal documentation page in plugin. Refer to doc.oxyprops.com
- **all**: add types
- **oxy**: woo global widget heading font size field now sets unit to none
- **oxy**: border radius menu triggers in woo global settings
- **oxy**: color menu now triggers in oxygen woo colorpicker fields
- **oxy**: structure context menu compatibility with Recoda Workspace
- **all**: custom element feature setting was active whatever the toggle state. This is fixed

## v1.9.0 (2023-07-04)

### Feat

- **all**: make a11y, cursors, position, scrollbars availabla as individual classes packs
- **all**: add breakpoint responsive screen reader classes

### Fix

- **brx**: class pezview on tab and hover is working again

## v1.8.0 (2023-06-26)

### Feat

- **oxy**: add emmet snippet demos
- **all**: added media queries text-align classes
- **oxy**: enhanced emmet and emmet context menu

### Fix

- **all**: switch to dynamic generated version for better cache management
- **brx**: normalize doesn't set default size anymore on Bricks native menu carets
- **all**: fix o-nopad and o-nomrg classes target property
- **all**: list classes
- **all**: typo in product base variable name

## v1.7.0 (2023-06-17)

### Feat

- bump 1.7

## v1.6.2 (2023-06-17)

### Feat

- **brx**: add dynamic ID and link sectioning elemnts to headings for proper landmarks
- **brx**: change structure menu labels

### Fix

- missed a function name in patch. ok now
- possibly undefined value now check before accessing
- **class-helpers.php**: handle deprecatePHP Deprecated:  strlen(): Passing null to parameter #1

## v1.6.2-dev2 (2023-06-16)

### Fix

- **class-helpers.php**: moved to regex for more efficient and future proof patch

### Refactor

- **class-helpers.php**: standardize iframe fix for all brx js files

## v1.6.2-dev1 (2023-06-16)

### Fix

- **deps**: update colorsjs.io from 0.4.3 to 0.4.5
- **deps**: update open-props from 1.5.7 to 1.5.9
- clean configs and bumb dependencies

## v1.6.1 (2023-04-17)
