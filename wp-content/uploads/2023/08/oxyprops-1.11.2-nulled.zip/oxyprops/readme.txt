=== OxyProps ===
Contributors: cbontems
Donate link: https://paypal.me/cbontems
Tags: oxygen builder, oxy props, open props, css custom proprties, css framework
Requires at least: 5.9
Tested up to: 6.2.2
Stable tag: 1.11.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Bringing Open Props and a Utility Classes Framework built upon it to Oxygen Builder enthusiasts.

== Description ==

[Open Props](https://github.com/argyleink/open-props) is an awesome set of expertly crafted Web Design Tokens in the form of CSS custom properties.  

OxyProps brings the power of Open Props and CSS Custom Properties to Oxygen Builder for lightning fast and consistent site design.  

* Built in Light and Dark modes.
* Find all Open Colors in your Oxygen Global Colors.
* Access the CSS properties from a context menu in the builder panel.
* Take advantage of hundreds of utility classes build with the properties and pre-registered for class suggestion.

Please visit the [OxyProps](https://oxyprops.com/) website for more details.

== Tested up to ==
# Bricks    - 1.8.4
# Oxygen    - 4.6 & 4.7 RC1
# WordPress - 6.2.2 & 6.3 Beta 1 (experimental)

== Changelog ==

## v1.11.1 (2023-07-30)

### Fix

- compatibility with BricksForge

## v1.11.0 (2023-07-13)

### Feat

- **all**: normalize assigns the new text-wrap balance to headings and text-wrap pretty to paragraphs
- **all**: new classes for the newly supported text-wrap property
- **all**: create new container fuid font sizes and make them available in fontsize context menus
- **all**: add new props for container based fluid typography
- **all**: add new container queries classes

### Fix

- **oxy**: fixed context menus in Oxygen triggering errors
- **all**: restored submenu items in dashboard

## v1.10.1 (2023-07-09)

### Fix

- **brx**: unlimited icon element now renders properly from dynamic data

## v1.10.0 (2023-07-07)

### Feat

- **all**: add settings to give users full control over theme-color meta

### Fix

- **all**: code cleanup and minimal documentation page in plugin. Refer to doc.oxyprops.com
- **all**: add types
- **oxy**: woo global widget heading font size field now sets unit to none
- **oxy**: border radius menu triggers in woo global settings
- **oxy**: color menu now triggers in oxygen woo colorpicker fields
- **oxy**: structure context menu compatibility with Recoda Workspace
- **all**: custom element feature setting was active whatever the toggle state. This is fixed

= 1.9.0 =

### Feat

- **all**: make a11y, cursors, position, scrollbars available as individual classes packs
- **all**: add breakpoint responsive screen reader classes

### Fix

- **brx**: class peview on tab and hover is working again

= 1.8.0 =
### Feat

- **oxy**: add emmet snippet demos
- **oxy**: enhanced emmet and emmet context menu
- **all**: added media queries text-align classes

### Fix

- **all**: switch to dynamic generated version for better cache management
- **brx**: normalize doesn't set default size anymore on Bricks native menu carets
- **all**: fix o-nopad and o-nomrg classes target property
- **all**: list classes
- **all**: typo in product base variable name

= 1.7.0 =
⚠ Potential breaking change (but no problems identified during testing)
# New    - All: Updated @wordpress/scripts to ^26.0.0 - This means React update to v18 as of WordPress 6.2. Admin App code refactor was needed. Please report any problems.

# New    - All: Update to Open Props 1.5.9. and other dependencies.
# New    - Brx: add dynamic ID and link sectioning elements to headings for proper landmarks
# Polish - Brx: For Bricksforge users, OP context menus do not trigger anymore in Bricksforge panel inputs.
# Fix    - All: Several minor fixes.
# Fix    - Brx: Improper font display in editor when using OP default font stacks. after update to Bricks 1.8

= 1.6.1 =
# New    - All: Update to Open Props 1.5.7.
# Polish - All: Unlimited icon elements now include a hover state color setting.
# Polish - All: Added a “noopener noreferrer” combo and “me” to the links relationship menu.
# Fix    - Brx: Lorem ipsum menu was triggered in customCSS when using Firefox.
# Fix    - Brx: Lorem generator menu sometimes appearing unexpectedly on botton left.
# Fix    - All: Fixed broken flex-between and flex-around classes names.

= 1.6.0 =
# New    - All: CSS Snippet for easy buttons customization in Custom CSS context menu.
# New    - All: Unlimited Icon custom element gives you access to 150k+ open source icons.
# New    - All: OxyProps now includes a dynamic Lorem Ipsum generator.
# Polish - All: Button components even more customizable.
# Polish - All: Cheat Sheet available on documentation site.
# Polish - All: Improved dashboard UI.
# Polish - Oxy: Light / Dark toggle element. You can now customize icon size on standard and touch screens and colors in light / dark mode and their respective hover states.
# Polish - Brx: Structure menu offers the choice to insert section only, container only, or container inside a section.
# Polish - Brx: List of selectors registered now defaults to “Large”.
# Polish - All: Context menus don't close unexpectedly on dragging.
# Fix    - Brx: Link relationship context menu triggers again.
# Fix    - All: Residual deprecation warnings after transitioning to PHP8 and over.

= 1.5.1 =
# New - Oxy: Text HTML Tags context menu.
# New - Oxy: New elements added to the structure components library.
# New - Brx: New components added to the structure components library.
# Fix - All: Flex Cards utility classes when using custom HTML tags.
# Fix - All: PHP 7.4 compatibility issues.

= 1.5.0 =
# New    - All: Accessibility - o-sr-only and o-not-sr-only utility classes.
# New    - All: Accessibility - OP now includes self hosted Atkinson Hyperlegible fonts as a fourth font stack.
# New    - Brx: FAQ custom Element for creating an accessible FAQ following W3C ARIA Authoring Practices Guide pattern.
# New    - Brx: Menu Bar custom Element for creating an accessible Menu Bar following W3C ARIA Authoring Practices Guide pattern.
# New    - Brx: Patterns Structure Tree context menu for injecting Patterns in the structure.
# New    - Brx: Components Structure Tree context menu for injecting Components in the structure.
# New    - Brx: HTML Elements Structure Tree context menu for injecting HTML Elements in the structure with proper tags.
# New    - Brx: Bricks Elements Structure Tree context menu for injecting Bricks Elements in the structure.
# New    - Brx: Basic Text HTML tags wrapper context menu.
# New    - Brx: Patch Bricks CSS hard coded default font family for blockquotes.
# Polish - All: Javascript codebase converted to Typescript
# Fix    - Brx: Multiplier functions in context menu.
# Fix    - Brx: When Normalize is active, text insertion cursor color is preserved in Bricks editor. It is set to brand color on front-end only.
# Fix    - Brx: Content sizes conflicts with Bricks default CSS.
# Fix    - Brx: o-super-centered Grid display in Bricks editor.


= 1.4.14 =
# Fix - Brx: Fixed adding classes with context menu that was broken with Bricks v1.7.
# Fix - All: Fixed navigation in plugin dashboard from WP menu.

= 1.4.13 =
# New - All: Option to choose (or not) to load OxyProps styles in Gutenberg Editor.
# Fix - Brx: Compatibility with Bricks v1.7beta (and hopefully the future official release)

= 1.4.12 =
# Polish - All: Theme color for supported browsers. https://caniuse.com/?search=theme-color
# Polish - All: Minor performance improvements.
# Fix    - Oxy: A CSS issue with custom toggle button border.

= 1.4.11 =
# Polish - All: Open Props library updated to v1.5.3.
# Fix    - All: PHP Warning in class Rest API when runing PHP 8.
# Fix    - Brx: A CSS conflict modifying UI elements (font sizes) in the Gutenberg Editor.
# Fix    - Brx: A PHP Error when trying to automatically log in from Plesk.
# Fix    - Brx: A JS conflict preventing OxyProps light/Dark toggle script to execute if a fluent form was present on the same page.
# Fix    - Brx: A CSS conflict between OxyProps rules and BricksExtras Back to Top element.
# Fix    - Brx: Lineheight specificity conflict with styles theme.

= 1.4.10 =
# New    - Brx: CSS Grid Props context menus.
# New    - All: Opacity context menu.
# Polish - All: Console Logs clean-up.
# Polish - All: Several code improvements for performance.
# Fix    - Brx: Following Bricks v1.6 release, fixed props context menus not appearing.

= 1.4.9 =
# New - All: Cursors classes.
# New - All: Text clamp classes.
# New - Brx: Ability to choose a pre-registered selectors set to improve performances.
# Fix - All: Fixed some descriptions of classes categories in dashboard
# Fix - Brx: On Plugin deactivation, pre-registered classes are deleted from the Bricks database.
# Fix - Brx: Fixed Moon icon positioning in builder
# Fix - Brx: Default links color applies to <a> tags if normalize or theme are selected
# Fix - Oxy: Fixed WP admin menu layout in gutenberg not full screen.
# Fix - Oxy: Fixed theme is not defined error in console when activating custom theme stylesheet.
# Fix - Oxy: Fixed custom stylesheet not activating properly.

= 1.4.8 =
# Fix - Brx: Possible conflict with translatable strings could cause bricks panel content and style tabs to be blank

= 1.4.7 =
# WP 6.1 - Oxygen 4.1 - Bricks 1.5.7.
# New - Brx: The schemes switcher element (already available in Oxygen) is now available for Bricks.
# Polish - All: Better ease classes polyvalence for animations and transitions.
# Fix - Brx: Bricks Normalize breaking WP admin menu layout in the widgets section.
# Fix - Brx: I18n elements string registration.
# Fix - Brx: Border radius context menu is now called inside Bricks form buidler.
# Fix - Brx: Potential conflict with JetEngine when using Bricks elements API.
# Fix - All: Minor fixes and cleanup.

= 1.4.6 =
# New    - Oxy: The Picsum menu, placeholder image generator, is now available in Oxygen too for image elements.
# Polish - All: Performances improvement.
# Polish - Brx: The classes menu opens on right click in the main input field even when an active class is present. Previously it was only on right click on the active class.
# Fix    - Brx: When setting a size in ch, the unit is now populated.
# Fix    - Brx: A case where class input would be blocked after creating a custom class.
# Fix    - Oxy: Live preview working for ch / vw / vh / % units.
# Fix    - Oxy: When setting a size in ch, the unit is now populated.
# Fix    - Oxy: A situation where the primary width unit was not updated on prop click.
# Fix    - Oxy: A situation where the border width unit was not updated on prop click.

= 1.4.5 =
# New - Underline and Wavy classes
# New - Inset classes
# New - Grid Autoflow classes
# Fix - A case where styling a text color in Bricks was not working.
# Fix - Color scheme responsiveness in Bricks templates editor.
# Fix - An 'invalid character' php warning because of an unwated space in default settings.

= 1.4.4 =
# New - Snap positioning classes.
# New - Resize classes.
# Polish - Access to flexbox and positioning classes from the classes context menu.
# Polish - Refined selection of pre-loaded classes for suggestion.
# Fix - Various typos.
# Fix - Css rule that did make action buttons invisible in the main class input.
# Fix - A case where colors would not live update in dashboard went setting a pure grey manually from RGB input fields.
# Fix - A case where chaining values for Link Relation keywords or background images in Oxygen did not work.
# Fix - A case where the unit would not change with prop click in Oxygen primary width input field.
# Fix - A case where font size would increase after update from 1.3.7. Thanks Leandro & Alexei!
# Fix - Another case where a php warning could be displayed in debug mode. Thanks François!

= 1.4.3 =
# Fix - A case where RAM classes would expand over the container when using Bricks. Thanks Darius!
# Fix - A case where warnigs would appear in debug mode when using Bricks. Thanks Petra!
# Fix - A case where the dark/light doggle would not appear in Oxygen. Thanks Leandro!
# Fix - A case where changing a color value with the context menu would trigger an error when saving. Thanks Rika!
# Fix - Visited links color formats in normalize.

= 1.4.2 =
# Fix: A PHP warning in debug log.
# Fix: --o-bw-hsl and --o-wb-hsl inverted behavior.
# Fix: Typos on the license screen.

= 1.4.1 =
# Polish: Delete legacy settings on user order.

= 1.4.0 =
# New: Bricks builder support.
# New: New plugin dashboard.
# New: Props preview from context menu.
# New: Classes context menu.
# New: CIELab color system.
# New: Color contrast accessibility checks.
# New: Edges and Corners masks available as props and utility classes.
# New: Fade-in-bloom and fade-out-bloom animations available as props and utility classes.
# New: Snap utility classes.
# New: Option to dequeue WordPress / Gutenberg inlined styles.
# Polish: Context menus can be moved around for better preview.
# Polish: 12-grid utility classes.
# Polish: Grids utility classes.
# Polish: Better database management.

= 1.3.8 =
# Fix: A case where OxyProps Styles were not loaded if using Oxygen Gutenberg Integration.

= 1.3.7 =
# Polish: improved classes suggestions dropdown keyboard navigation.
# Fix: A case where OP Context menu was triggered by error in the current class field.
# Fix: A case where class previews on keyboard navigation and mouse hover could conflict.
# Fix: A case where the new class preview feature intoduced in v1.3.6 was not working. Thanks Petra Jovkov.
# Fix: A case where OxyProps CSS was not rendered on front end if license key was acciddentally deleted. Thanks Ingo.

= 1.3.6 =
# New: Live preview of classes in autosuggested list.
# Polish: Added default Aria Roles to sections in the structure panel context menu.
# Polish: Added <label> element to forms in the structure panel context menu.
# Polish: Structure panel context menu elements with preset attributes. 
# Fix: OP Context menu was triggered by error ID and classes fields, and  in code block fields.

= 1.3.5 =
# Fix: A case where FireFox would not load OxyProps in-buidler Javascript

= 1.3.4 =
# New: Add Elements context menu for the structure panel.
# Fix: Encrypted code in base file was reported as potentially malicious by some hosts.
# Fix: Typo for HSL version of text colors in the dark mode theme

= 1.3.3 =
# Fix: Number rounding in color conversion functions did cause custom colors to vary. Thanks Ingo Wo for reporting!

= 1.3.2 =
# New: "Sub" version of each fluid font for matching subheadings.
# New: Fluid fonts range align with static fonts range 00 -> 8.
# New: Full automatic and customizable fluid font system.
# Polish: Better tab and arrow keys keyboard navigation for suggested classes.
# Fix: Tiny visual detail in the light / dark toggle sun icon.

= 1.3.1 =
# Polish: Removed annoying title attibute on builder light/dark toggle as tooltip is enough.
# Polish: Better text readability for colors context menu.
# Polish: Text & Surfaces usable as HSL props.
# Fix: Customizable theme stylesheet now includes accent color props.

= 1.3.0 =
* New: Light / Dark toggle in Oxygen Editor for easy switch during development.
* New: Additional logical color "Accent" added to the framework.
* New: Black and White are available as props --o-black and --o-white.
* Polish: CSS file size improvement.
# Fix: Surface-1 is set as the default background color even when normalize is deactivated.
# Fix: Minor fixes.

= 1.2.6 =
* Polish: Full bundle CSS file size reduced by 8.13% from (Gzipped) 71.69 KiB to 65.86 KiB.
* Polish: Updated stylesheets file sizes in dashboard tooltips.
* Fix: Consistent range between props and classes for asymetrical grids.

= 1.2.5 =
* New: Position sticky added as class and custom CSS context menu
* Fix: An error could occur at license activation in specific conditions.

= 1.2.4 =
* Polish: When created, OxyProps selector folders are disabled by default.
* Fix: Mutliplier appllied to numerical value.
* Fix: Mutliplier for width property.
* Fix: Context menu CSS when normalize is disabled.

= 1.2.3 =
* New: Flex Child behavior context menus
* New: Most classes are now registered into Oxygen for reference and autosuggestion
* Polish: Better context menu logic for reliability and scalability. 
* Fix: Now handles multiple custom attributes on a single element. 
* Fix: Compatibility with Recoda Workspace for border widths.
* Fix: Custom CSS context menu now works with Firefox.
* Fix: TextShadows turned to scientific notation for build reliability.

= 1.2.2 =
* New: Ipsum Text context menu
* Polish: Even better color schemes management.

= 1.2.1 =
* Fix: Minor CSS fixes.

= 1.2.0 =
* New: User can define custom colors.
* Fix: Flex Cards CSS specificity conflict with Oxy ct_div_block.

= 1.1.2 =
* New: Custom CSS context menu.
* Polish: Ram is now able to adapt to parent width.
* Polish: JS code clean-up.
* Fix: Context menu works in global settings panel.
* Fix: Invert mode with user system preferences.
* Fix: h1 max-inline-size specificity.

= 1.1.1 =
* Polish: OxyProps default Font Stacks are now available from Oxygen Dropdown in global settings.
* Fix: Font family utility classes specificity.

= 1.1.0 =
* New: Context menu for custom CSS field
* New: --o-shadoweight-{1-8} props
* New: Customizable Light Dark toggle Element
* Fix: Oxygen Plus menu CSS

= 1.0.0 =
* Initial Release